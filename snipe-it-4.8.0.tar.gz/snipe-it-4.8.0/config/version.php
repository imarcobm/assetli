<?php
return array (
  'app_version' => 'v4.8.0',
  'full_app_version' => 'v4.8.0 - build 4186-g893454dca',
  'build_version' => '4186',
  'prerelease_version' => '',
  'hash_version' => 'g893454dca',
  'full_hash' => 'v4.8.0-g893454dca',
  'branch' => 'master',
);